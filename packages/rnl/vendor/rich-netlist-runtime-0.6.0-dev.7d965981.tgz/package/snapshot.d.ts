// The snapshot of the editor interface (crates/rnl-view/src/snapshot.rs) as TypeScript
// declarations, generated from its Rust types by ts-rs. Do not edit: after changing the types, run
//   RNL_BLESS=1 cargo test -p rnl-view types
// The snapshot is plain JSON; these are its shapes, with nothing to load at run time.

import type { Diagnostic, Document, Run } from "./document.js";

/**
 * A document as the editor interface gives it: its files, packages and diagnostics, and each
 * drawing level's host circuit and model, as [`Parts`] ask.
 */
export type Snapshot = {
  /**
   * "rnl-snapshot/1".
   */
  schema: string,
  /**
   * The version of the runtime that made it.
   */
  runtime: string,
  /**
   * The language version the main file declares, or the one a file without it is read as (16.1).
   */
  language: string,
  /**
   * The fingerprint of what it is made from (3.7), 32 hexadecimal digits: the texts of the host
   * files and of the packages read, and the build's options. The same for the same texts and
   * options, whatever their line endings; new after any change to a text, a space included.
   */
  revision: string,
  /**
   * "spice" or "spectre".
   */
  dialect: string,
  /**
   * The packages in effect, by name and version, in the order they are brought in: those of
   * the standard package first, the packages it references before it (16.2, 16.3).
   */
  packages: Array<PackageUse>,
  /**
   * The host files, as in the Document: the opened file first.
   */
  files: Array<FileRef>,
  /**
   * The drawing levels, as in the Document.
   */
  levels: Array<LevelSnapshot>,
  diagnostics: Array<Diagnostic>,
  /**
   * Why the document could not be interpreted at all.
   */
  failed: string | null,
  /**
   * The Document, when `parts.drawing` asks for it.
   */
  drawing?: Document,
};

export type PackageUse = { name: string, version: string };

export type FileRef = {
  /**
   * As the Document's `SourceFile::path`.
   */
  path: string,
  /**
   * As shown.
   */
  name: string,
  /**
   * The format the file was read with, as the Document's `SourceFile::format`: only when the
   * netlist's files are of more than one format, or the request set a format for some.
   */
  format?: string,
};

/**
 * A drawing level.
 */
export type LevelSnapshot = {
  /**
   * `subckt:NAME` for a subcircuit, `file:PATH` for the file level, PATH as in `files`.
   */
  id: string,
  /**
   * "file" or "subckt".
   */
  kind: string,
  /**
   * The subcircuit's name, or the file's.
   */
  name: string,
  /**
   * The file it is defined in, an index into `files`.
   */
  file: number | null,
  /**
   * The line of a subcircuit's header; 0 for a file level.
   */
  line: number,
  /**
   * What the level lacks without a solver, as the Document's `Level::status`.
   */
  status: string | null,
  host?: HostLevel,
  model?: LevelModel,
};

/**
 * The host circuit of a level, read only. Names are written as on the host's lines; a net
 * written several ways goes by its first.
 */
export type HostLevel = {
  /**
   * The subcircuit's ports in order, as net ids.
   */
  ports: Array<string>,
  /**
   * The instances in netlist order.
   */
  instances: Array<HostInstance>,
  /**
   * The nets: the ports first, then as the instances name them.
   */
  nets: Array<HostNet>,
};

export type HostInstance = {
  /**
   * `#M1`.
   */
  id: string,
  /**
   * An instance of a subcircuit, defined in the netlist or not.
   */
  subckt: boolean,
  /**
   * The name in the model position: a model, a subcircuit or a Spectre master.
   */
  master: string | null,
  /**
   * The type, lower case, as the rules and the `${type}` of a text read it: the host's (an M
   * card, the type of a model card) or else DEVICE's (6.12); none where neither gives one.
   */
  type: string | null,
  terminals: Array<HostTerminal>,
};

export type HostTerminal = {
  /**
   * From 1, in the order of the line's nodes.
   */
  n: number,
  /**
   * From DEVICE, the subcircuit's ports or the adapter's defaults (6.4, 6.12).
   */
  name: string | null,
  /**
   * `&vout`.
   */
  net: string,
};

export type HostNet = {
  /**
   * `&vout`, `&"vdd!"`.
   */
  id: string,
  global: boolean,
  port: boolean,
  /**
   * The usages it is a member of in the level ([`UsageOf`]); only for a net that is in some.
   */
  usages?: Array<UsageOf>,
};

/**
 * A usage an object is a member of, in the object's level, by the usage's id: what the Document
 * gives as `Object::usages` (`MemberOf`). The usage's own object view lists the usages it is a
 * member of in turn: the chain upward.
 */
export type UsageOf = {
  /**
   * "usage", or "group", a set marked with GROUP (11.5), by its id in `groups`.
   */
  kind: string,
  /**
   * The usage's id, as its object view has it: `%dp1`, `@file:line:col`. A failed application,
   * which made no usage, has the name it binds, or where it is written.
   */
  id: string,
  /**
   * Its definition, such as `$DIFFERENTIAL_PAIR`, or in a 0.4 level, `%dot` for one a level defines, whose `%` a level before 0.4 leaves out;
   * empty for a group, and when a failed statement names none.
   */
  definition: string,
  /**
   * The roles the object fills in it: for a group, `members`; none for a group within this one,
   * as `MemberOf::roles`.
   */
  roles: Array<RoleOf>,
  /**
   * The statement that applies the definition: its file, by index in `files` when it is one of
   * them, and its first line.
   */
  file: number | null,
  line: number,
  /**
   * "written", "solver", "rule" or "body", as `MemberOf::source`.
   */
  source: string,
  /**
   * For a usage a rule made: the rule's package and where the rule is written.
   */
  rule?: RuleAt,
  /**
   * For a usage the body of a definition made: the usage whose definition it is, by id.
   */
  made_in?: string,
  /**
   * "in-effect", "failed", "overridden" or "disabled", as `MemberOf::state`.
   */
  state: string,
  /**
   * Why it failed or was overridden.
   */
  reason?: string,
};

/**
 * A role an object fills in a usage.
 */
export type RoleOf = {
  /**
   * The role, such as `in_p`.
   */
  role: string,
  /**
   * The role is a set role (9.4), and the object one of its members.
   */
  set: boolean,
  /**
   * How the role names the object, as the snapshot writes ids: `#M1`, `#M5:1` for a terminal of
   * an instance by its number, `&vdd`, `%dp1`, `%g1:p` for a terminal of a usage.
   */
  member: string,
  /**
   * For a terminal: its name, such as `d`, when it has one; its number otherwise.
   */
  terminal: string | null,
};

/**
 * Where a rule is written.
 */
export type RuleAt = { package: string, file: string, line: number };

/**
 * A set marked with GROUP (11.5), which a viewer lists with the usages.
 */
export type GroupView = {
  /**
   * Whole grid-unit addition to the solver's default spacing (11.5).
   */
  spacing_x?: number,
  /**
   * Whole grid-unit addition to the solver's default spacing (11.5).
   */
  spacing_y?: number,
  /**
   * `%core` when a record of the level names it; otherwise where GROUP is written,
   * `@file:line:col`, with `#n` after it when several groups have that place.
   */
  id: string,
  /**
   * Its members in order, each an id or a point, nested sets followed down.
   */
  members: (string | [number, number])[],
  /**
   * The statement that gives GROUP: its file, by index in `files` when it is one of them, and
   * its first line.
   */
  file: number | null,
  line: number,
  /**
   * "written", "solver", "rule" or "body", as `UsageOf::source`.
   */
  source: string,
  rule?: RuleAt,
  /**
   * For a group the body of a definition made: the usage whose definition it is, by id.
   */
  made_in?: string,
  /**
   * "in-effect", or "disabled" when PRIORITY turns it off (11.5, 14.8).
   */
  state: string,
  /**
   * The groups it is within, the smallest ones, and the usages it fills a role of
   * ([`UsageOf`]); only for a group that has some.
   */
  usages?: Array<UsageOf>,
};

/**
 * What the RNL makes of a level. Coordinates are scene units, y up.
 */
export type LevelModel = {
  /**
   * The symbols the objects are drawn with, and the level's own.
   */
  symbols: Array<SymbolRef>,
  /**
   * A subcircuit's own symbol, `#` (9.2.6), by its id in `symbols`: what its instances are drawn
   * with when they are given no other. Null for a file level, and for a subcircuit without one.
   */
  symbol: Slot<string>,
  /**
   * The instances, bundles and usages, drawn or not.
   */
  objects: Array<ObjectView>,
  /**
   * The named points.
   */
  points: Array<PointView>,
  /**
   * The wires that have their vertices.
   */
  wires: Array<WireView>,
  /**
   * The texts with an anchor and something to show.
   */
  texts: Array<TextView>,
  /**
   * The graphics of the scene (13.4) that have their points, in the order written.
   */
  shapes: Array<ShapeView>,
  /**
   * Compound annotations retain their identity and local graphics.
   */
  annotations?: Array<AnnotationView>,
  /**
   * The sets marked with GROUP (11.5), in the order of writing; only for a level that has some.
   */
  groups?: Array<GroupView>,
  /**
   * For a 0.4 level, the definition of its junction dots, which SOLVER-CONFIG `junction` selects
   * (14.10), readable before any solve; absent before 0.4, and when none is selected.
   */
  junction?: JunctionView,
};

/**
 * A symbol, by an id unique in the level's `symbols`: its name, or its name and where it is
 * defined after `@` when two of the level's symbols share the name.
 */
export type SymbolRef = {
  id: string,
  /**
   * `$NMOS`, or `%ota5t` for a symbol defined in a level.
   */
  name: string,
  /**
   * The package that defines it.
   */
  package: string | null,
  /**
   * The level that defines it, by its id.
   */
  level: string | null,
  /**
   * The viewer's own stand-in box (9.2.6).
   */
  default: boolean,
  /**
   * For a symbol the document defines, such as a block's (9.2.6), what it is made of, in its
   * own coordinates; for a package's symbol, null: its name says it.
   */
  definition: SymbolDefinition | null,
};

/**
 * A symbol's box, pins and graphics, in its own coordinates, y up.
 */
export type SymbolDefinition = {
  /**
   * x1, y1, x2, y2: the box the symbol writes, or the extent of its graphics.
   */
  box: [number, number, number, number],
  /**
   * The symbol writes its box.
   */
  box_written: boolean,
  pins: Array<SymbolPin>,
  /**
   * Its graphics, texts left out, in the order written.
   */
  prims: Array<SymbolPrim>,
};

export type SymbolPin = {
  /**
   * Local names of a 0.4 pin, in binding order; empty for an unnamed pin.
   */
  names?: Array<string>,
  /**
   * Whether the binding is a bus, including a one-element array.
   */
  bus?: boolean,
  /**
   * The terminals at the pin, by number or name as the symbol writes them.
   */
  terminals: Array<string>,
  at: [number, number],
  /**
   * The exit direction in degrees: 0 right, 90 up, 180 left, 270 down.
   */
  dir: number | null,
  /**
   * The pin's name for display (9.2.4): as written, and as lines of runs.
   */
  label: PinLabel | null,
};

export type PinLabel = { markup: string, lines: Array<Array<Run>> };

/**
 * A graphic of a symbol (9.2.5).
 */
export type SymbolPrim = {
  /**
   * "line", "rectangle", "circle", "ellipse", "arc" or "bezier".
   */
  shape: string,
  /**
   * The centre of a rectangle, circle or ellipse with its size, else its points.
   */
  points: Array<[number, number]>,
  /**
   * Its parameters: width, height, radius, fill, arrow.
   */
  params: Record<string, string | number>,
  /**
   * The style properties it writes.
   */
  style: Record<string, string | number | boolean>,
};

/**
 * A value and the statement it comes from (`source`, a key of `sources`; null for now).
 */
export type Slot<T> = { value: T | null, source: string | null };

export type ObjectView = {
  /**
   * The owner id of a 0.4 usage's pin attachment; absent without a unique structural host.
   */
  pin_of?: string,
  /**
   * The enclosing 0.4 usage's id. Follow this chain for inherited pin attachment.
   */
  parent?: string,
  /**
   * Unique in the level: `#M1`, `%gnd1`, or `@file:line:col` where the statement that made an
   * object without a name of its own is, with `#n` after it when it made several.
   */
  id: string,
  /**
   * "instance", "bundle" or "usage".
   */
  kind: string,
  /**
   * The host instances it draws: one for an instance, the members of a bundle, none for a usage.
   */
  host: Array<string>,
  /**
   * A usage's definition, such as `$GROUND`, or in a 0.4 level, `%dot` for one a level defines, whose `%` a level before 0.4 leaves out.
   */
  definition: string | null,
  /**
   * A usage's roles, each with the id of what it is attached to, or a point; a set role (9.4)
   * with the list of its members, each an id or a point, nested sets followed down, empty when the
   * role is left empty.
   */
  attach: Record<string, string | [number, number] | (string | [number, number])[]> | null,
  /**
   * A usage's parameters as the statement that applies it writes them, each value of the type it
   * is written in (a string, a number, a truth value, or a list of them); the definition's
   * defaults are not among them. Only for a usage that writes some.
   */
  params?: Record<string, string | number | boolean | unknown[]>,
  /**
   * The style properties the document's records give it (9.3), each as it wins in the style
   * queue (8.3), such as `linecolor`; a package's, such as the standard package's defaults, are
   * left out. Only for an object that the document gives some.
   */
  style?: Record<string, string | number | boolean>,
  /**
   * The id of its symbol in `symbols`.
   */
  symbol: Slot<string>,
  /**
   * Its registration point; null when it has none yet.
   */
  at: Slot<[number, number]>,
  /**
   * "R0", "R90", "R180", "R270", "MX", "MY", "MXR90" or "MYR90".
   */
  orient: Slot<string>,
  /**
   * The assigned symbol's pins. In 0.4 these include unplaced pins with a null scene position.
   */
  pins: Array<PinView>,
  /**
   * The usages it is a member of in the level, with the roles it fills, those of its terminals
   * too for an instance ([`UsageOf`]); only for an object that is in some.
   */
  usages?: Array<UsageOf>,
};

export type PinView = {
  /**
   * The independent pin object kind, present in 0.4.
   */
  kind?: "pin",
  /**
   * Opaque editor id. Use `reference`, when present, for writing RNL source.
   */
  id?: string,
  /**
   * Zero-based physical index in the owner's assigned symbol.
   */
  index?: number,
  names?: Array<string>,
  bus?: boolean,
  /**
   * A source expression that reaches this exact pin; absent when none is available.
   */
  reference?: string,
  /**
   * Symbol-local position, before the owner's orientation and translation.
   */
  local_at?: [number, number],
  /**
   * An instance's terminals by number, `#M1:1`; a usage's roles, `p`.
   */
  terminals: Array<string>,
  /**
   * Scene position; null when the owner has no position yet.
   */
  at: [number, number] | null,
  /**
   * The exit direction after the orientation, in degrees: 0 right, 90 up, 180 left, 270 down.
   */
  dir: number | null,
  /**
   * The nets at the pin, as ids.
   */
  nets: Array<string>,
};

export type PointView = {
  /**
   * `%j1`.
   */
  id: string,
  at: Slot<[number, number]>,
  /**
   * A junction dot is drawn at it.
   */
  junction: boolean,
};

export type WireView = {
  id: string,
  nets: Array<string>,
  /**
   * The vertices as the statement writes them.
   */
  via: Array<Vertex>,
  /**
   * The vertices after the routing mode.
   */
  points: Array<[number, number]>,
  mode: string,
  /**
   * The style properties the document's records give it; a package's, such as the standard
   * package's defaults, are left out.
   */
  style: Record<string, string | number | boolean>,
};

/**
 * A vertex of a wire.
 */
export type Vertex =
  | { terminal: string }
  | { owner: string, pin: number, reference: string | null }
  | { point: string }
  | { usage: string, role: string }
  | { at: [number, number] };

export type TextView = {
  /**
   * `#M1::name` for a label with a key; else as an object's.
   */
  id: string,
  /**
   * The id of the object it is attached to, or of the point, for a text at a point the level
   * names, such as `%j1`; null for a text at a point written in place, such as `(10, 0)`, or at
   * one that the level does not name alone.
   */
  attach: string | null,
  /**
   * For a text attached to a point, named or written in place, the point's position `[x, y]`:
   * what it hangs on even where `attach` is null. Null for a text at no point, and while its
   * point has no position yet, such as `(_, 7)`.
   */
  attach_point: [number, number] | null,
  /**
   * The key of a label, such as "name".
   */
  key: string | null,
  /**
   * The text as written, before `${…}` is read (13.6).
   */
  markup: Slot<string>,
  /**
   * The document's records write it, or a part of it; false for a label its symbol alone gives,
   * such as the formula of a block.
   */
  written: boolean,
  /**
   * What it shows, as the Document's texts give it.
   */
  lines: Array<Array<Run>>,
  anchor: [number, number],
  halign: string,
  valign: string,
  rotate: number,
  /**
   * Effective fixed rotation, when supplied by a TEXT statement.
   */
  fix_rotate?: boolean,
  /**
   * Effective upright, when supplied by a TEXT statement.
   */
  upright?: boolean,
  /**
   * False when its style in effect hides it, `textvisible=false` (9.3), whether the document or a
   * package gives it, as a package's rule hiding default labels does; absent when it is shown.
   * A hidden text takes no room and is not drawn, but its content stays.
   */
  visible?: boolean,
  /**
   * Its size, from the document or a package, when one gives it.
   */
  size: number | null,
  /**
   * The style properties the document's records give it, such as `textcolor`, `bold` and
   * `italic`; a package's are left out.
   */
  style: Record<string, string | number | boolean>,
};

/**
 * A graphic of the scene (13.4), as an `add-shape` op writes one.
 */
export type ShapeView = {
  /**
   * `%box1` when the level names it; else where the statement that made it is, as an object's.
   */
  id: string,
  /**
   * "line", "rectangle", "circle", "ellipse", "arc" or "bezier".
   */
  shape: string,
  /**
   * The centre of a rectangle, circle or ellipse with its size, else its points; a point given
   * by a reference, such as `%j1`, where it is.
   */
  points: Array<[number, number]>,
  /**
   * Its parameters: width, height, radius, fill, arrow.
   */
  params: Record<string, string | number>,
  /**
   * The style properties the document's records give it; a package's are left out.
   */
  style: Record<string, string | number | boolean>,
  /**
   * "bottom", "middle" or "top".
   */
  layer: string,
};

export type AnnotationView = { id: string, source_kind: string, source: string, anchor_kind: string, anchor_object: string | null, anchor: [number, number], rotate: number, mirror: boolean, style: Record<string, string | number | boolean>, layer: string, graphics: Array<AnnotationGraphic> };

export type AnnotationGraphic = {
  shape: string,
  points: Array<[number, number]>,
  params: Record<string, string | number>,
  style: Record<string, string | number | boolean>,
  lines: Array<Array<Run>>,
  text: string | null,
  text_refs: Array<string>,
  halign: string | null,
  valign: string | null,
  rotate: number | null,
  fix_rotate: boolean,
  upright: boolean | null,
  /**
   * For a text, false when its style in effect, its own over the annotation's, hides it
   * (`textvisible=false`, 9.3); absent when it is shown.
   */
  visible?: boolean,
};

/**
 * The junction dots of a 0.4 level ([`LevelModel::junction`]).
 */
export type JunctionView = {
  /**
   * The definition, as a usage names it: `$JUNCTION`, or `%dot` for one a level defines.
   */
  definition: string,
  /**
   * The symbol its dots in the level are drawn with, by its id in `symbols`, whose `definition`
   * gives its graphics, such as the radius of its circle; null while the level has no dot yet,
   * such as before a solve, as the symbol a rule gives a usage is only known for one.
   */
  symbol: string | null,
};
